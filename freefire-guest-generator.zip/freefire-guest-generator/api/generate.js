// VILGRIM ⚡ — API Generator Guest FF
// Endpoint utama: /api/generate

export default async function handler(req, res) {
  // Set CORS biar bisa diakses dari mana aja
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  // Handle preflight request
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method tidak diizinkan' });
  }

  try {
    const { region = 'ID', prefix = 'KNS' } = req.body || {};

    // 1. Bikin password acak
    const password = 'XORA_' + generateHex(16);
    
    // 2. Bikin nickname acak dengan prefix
    const nickname = prefix + generateString(7);

    // 3. Panggil proses bikin akun guest
    const hasil = await bikinAkunGuest({ password, nickname, region });

    if (!hasil.success) {
      return res.status(500).json({
        success: false,
        error: hasil.error
      });
    }

    // 4. Format JSON sesuai contoh kamu
    const response = {
      success: true,
      uid: hasil.uid,
      account_id: hasil.account_id,
      access_token: hasil.access_token,
      jwt_token: hasil.jwt_token,
      open_id: hasil.open_id,
      name: nickname,
      password: password,
      region: region,
      forced_region: region,
      forced_name_prefix: prefix,
      rarity: 'JELEKBET',
      rarity_score: 10,
      status: 'full_login',
      stage: 'complete',
      created_at: new Date().toISOString(),
      attempts_made: 1,
      elapsed_sec: hasil.elapsed,
      workers: 5
    };

    return res.status(200).json(response);

  } catch (error) {
    return res.status(500).json({
      success: false,
      error: error.message
    });
  }
}

// Fungsi bikin hex acak
function generateHex(length) {
  const chars = '0123456789ABCDEF';
  let hasil = '';
  for (let i = 0; i < length; i++) {
    hasil += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return hasil;
}

// Fungsi bikin string acak
function generateString(length) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let hasil = '';
  for (let i = 0; i < length; i++) {
    hasil += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return hasil;
}

// Fungsi inti bikin akun guest FF
async function bikinAkunGuest({ password, nickname, region }) {
  const mulai = Date.now();

  try {
    // Di sini harus implementasi asli protokol FF:
    // - OAuth guest grant
    // - Serialisasi Protobuf
    // - Enkripsi AES-128-CBC
    // - Login ke endpoint major
    //
    // Referensi open source: kaifcodec/freefire-jwt-generator-api

    // Simulasi dulu (harus diganti dengan panggilan asli)
    const uid = Math.floor(1000000000 + Math.random() * 9000000000).toString();
    const accountId = Math.floor(10000000000 + Math.random() * 90000000000).toString();
    const accessToken = generateHex(64);
    const openId = generateHex(32);
    
    // Bikin JWT
    const jwtToken = bikinJwt({
      account_id: parseInt(accountId),
      nickname: nickname,
      region: region,
      uid: uid
    });

    return {
      success: true,
      uid,
      account_id: accountId,
      access_token: accessToken,
      jwt_token: jwtToken,
      open_id: openId,
      elapsed: ((Date.now() - mulai) / 1000).toFixed(2)
    };

  } catch (error) {
    return {
      success: false,
      error: error.message
    };
  }
}

// Bikin JWT Token
function bikinJwt(payload) {
  const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
  const body = Buffer.from(JSON.stringify({
    ...payload,
    exp: Math.floor(Date.now() / 1000) + 86400 * 30,
    iat: Math.floor(Date.now() / 1000)
  })).toString('base64url');
  
  // Perlu kunci HMAC asli dari server FF
  const signature = 'tanda_tangan_dummy_' + generateHex(32);
  
  return `${header}.${body}.${signature}`;
}
